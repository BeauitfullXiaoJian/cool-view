import { Component, Input } from '@angular/core';

@Component({
    selector: 'app-progress',
    template: `
    <div class="progress">
        <div class="progress-bar" [ngStyle]="{width: value + '%' }">
            <ng-content></ng-content>
        </div>
    </div>`,
    styles: [`
        .progress{
            display: -webkit-box;
            display: -ms-flexbox;
            display: flex;
            height: 1rem;
            overflow: hidden;
            font-size: .75rem;
            background-color: #e9ecef;
            border-radius: .25rem;
        }
        .progress-bar {
            display: -webkit-box;
            display: -ms-flexbox;
            display: flex;
            -webkit-box-orient: vertical;
            -webkit-box-direction: normal;
            -ms-flex-direction: column;
            flex-direction: column;
            -webkit-box-pack: center;
            -ms-flex-pack: center;
            justify-content: center;
            color: #fff;
            text-align: center;
            background-color: #007bff;
            transition: width .6s ease;
        }
    `]
})
export class ProgressComponent {

    @Input() value: number;

    construct() {
        // 默认进度条进度为0
        this.value = 0;
    }
}
