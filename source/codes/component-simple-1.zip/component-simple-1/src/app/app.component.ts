import { Component } from '@angular/core';

@Component({
    selector: 'app-root',
    templateUrl: './app.component.html',
    styleUrls: ['./app.component.css']
})
export class AppComponent {

    progressValue: number;

    constructor() {
        this.progressValue = 0;
        setInterval(() => {
            if (++this.progressValue > 100) {
                this.progressValue = 0;
            }
        }, 100);
    }
}
