import { Component, ElementRef, Input, ContentChild } from '@angular/core';

@Component({
    selector: 'app-child',
    template: '<div>{{title}}</div>',
})
export class ChildComponent {
    @Input() title: string;
    @ContentChild('dom')
    set divElementRef(elementRef: ElementRef) {
        console.log(elementRef.nativeElement);
    }
}
