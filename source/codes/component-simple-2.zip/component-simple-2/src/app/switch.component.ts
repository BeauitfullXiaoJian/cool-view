import { Component, Input, Output, EventEmitter } from '@angular/core';

@Component({
    selector: 'app-switch',
    template: `
        <span class="switch" (click)="changeStatus()" [ngClass]="{'switch-open':status,'switch-close':!status}">
            <span class="switch-bar"></span>
        </span>
    `,
    styles: [`
        .switch {
            display: inline-block;
            height: 30px;
            width: 60px;
            border-radius: 18px;
            padding: 2px;
        }
        .switch-bar {
            display: inline-block;
            height: 30px;
            width: 30px;
            border-radius: 15px;
            background-color: white;
        }
        .switch-open {
            background-color: #1f7bfb;
        }
        .switch-close {
            background-color: #ccc;
        }
        .switch-open .switch-bar {
            transition: margin 0.3s linear;
            margin-left: 30px;
        }
        .switch-close .switch-bar {
            transition: margin 0.3s linear;
            margin-left: 0px;
        }
    `]
})
export class SwitchComponent {

    @Input() status: boolean;

    @Output() statusChange = new EventEmitter<boolean>(false);

    construct() {
        // 默认状态为false，关闭状态
        this.status = false;
    }

    /**
     * 变更开关状态
     */
    changeStatus() {
        this.status = !this.status;

        // 每次状态被改变的时候，我们把状态发射出去
        this.statusChange.emit(this.status);
    }
}
