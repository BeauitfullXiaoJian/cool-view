import { Component } from '@angular/core';

@Component({
    selector: 'app-root',
    templateUrl: './app.component.html',
    styleUrls: ['./app.component.css']
})
export class AppComponent {

    // 开关状态
    switchStatus = false;
    /**
     * 显示一条消息
     * @param {boolean} status 开关状态
     */
    showMessage(status: boolean) {
        alert(status ? '开灯' : '关灯');
    }
}
