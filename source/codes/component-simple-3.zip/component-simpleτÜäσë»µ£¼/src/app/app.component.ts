import { Component } from '@angular/core';

@Component({
    selector: 'app-root',
    templateUrl: './app.component.html',
    styleUrls: ['./app.component.css']
})
export class AppComponent {

    rootNode = {
        data: { title: '根节点' },
        childNodes: [
            {
                data: { title: '一级节点-1' },
                childNodes: [
                    {
                        data: { title: '二级节点-1-1' },
                        childNodes: []
                    }
                ]
            },
            {
                data: { title: '一级节点-2' },
                childNodes: [
                    {
                        data: { title: '二级节点-2-1' },
                        childNodes: []
                    },
                    {
                        data: { title: '二级节点-2-2' },
                        childNodes: [
                            {
                                data: { title: '三级节点-2-2-1' },
                                childNodes: []
                            }
                        ]
                    }
                ]
            }
        ]
    };

    // 被点击的节点
    activeNode: Node;
}
