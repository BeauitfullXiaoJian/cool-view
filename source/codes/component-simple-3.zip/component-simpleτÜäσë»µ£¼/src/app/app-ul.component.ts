import { Component, Input, Output, EventEmitter } from '@angular/core';

@Component({
    selector: 'app-ul',
    template: `
    <ul>
        <li>
            <div (click)="sendClickEvent(node)">{{node.data | json}}</div>
            <app-ul *ngFor="let item of node.childNodes" [node]="item" (clickEvent)="sendClickEvent($event)"></app-ul>
        </li>
    </ul>
    `
})
export class AppUlComponent {

    @Input() node: Node;

    @Output() clickEvent = new EventEmitter(false);

    /**
     * 发射触发事件的节点
     * @param node 触发点击事件的节点
     */
    sendClickEvent(node: Node) {
        this.clickEvent.emit(node);
    }
}
export interface Node {
    // 节点数据
    data: any;
    // 子级节点（多个）
    childNodes: Node[];
}
